<?php

class Elementor_About_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'about_widget';
	}

	public function get_title() {
		return esc_html__( 'About Section', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-user-circle-o';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'about', 'cv' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'About Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ** All controls start
	
		// About Title
		$this->add_control(
			'about_title',
			[
				'label' => esc_html__( 'About Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Welcome To Halim', 'webar-addons' ),
				'placeholder' => esc_html__( 'Write Your Title', 'webar-addons' ),
				'show_label'  => true,
				'separator'   => 'before'
			]
		);

		// About Description
		$this->add_control(
			'about_desc',
			[
				'label' => esc_html__( 'About Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda distinctio maxime laborum delectus aliquam ipsum itaque voluptatem non reiciendis aliquid totam facere, tempora iure iusto adipisci doloremque in, amet, alias nostrum. Explicabo reprehenderit.', 'webar-addons' ),
				'placeholder' => esc_html__( 'Write your Description', 'webar-addons' ),
				'label_block' => 'true',
				'separator'   => 'before'
			]
		);

		// About Button Text
		$this->add_control(
			'about_btn_text',
			[
				'label' => esc_html__( 'Button Text', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Read More', 'webar-addons' ),
				'placeholder' => esc_html__( 'Your BTN Name', 'webar-addons' ),
				'show_label'  => true,
				'separator'   => 'before'
			]
		);

		//Button URL
		$this->add_control(
			'about_btn_url',
			[
				'label' => esc_html__( 'Button URL', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'webar-addons' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);

		
        $this->end_controls_section();

		//About Features
		$this->start_controls_section(
			'about_section',
			[
				'label' => esc_html__( 'About Feature', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);



		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'about_feature_icon', 
				[
					'label' => esc_html__( 'Feature Icon', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'default' => [
						'value' => 'fas fa-star',
						'library' => 'solid',
					],
				]
		);

		$repeater->add_control(
			'about_feature_title', [
				'label' => esc_html__( 'Feature Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'List Content' , 'webar-addons' ),
				'label_block' => true
				
			]
		);

		$repeater->add_control(
			'about_feature_desc', [
				'label' => esc_html__( 'Feature Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'List Content' , 'webar-addons' ),
				'label_block' => true
				
			]
		);


		$this->add_control(
			'about_feature_list',
			[
				'label' => esc_html__( 'Feature List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'about_feature_icon' => esc_html__( 'Feature Icon', 'webar-addons' ),
						'about_feature_title' => esc_html__( 'Our Mission', 'webar-addons' ),
						'about_feature_desc' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry', 'webar-addons' ),
					],

					[
						'about_feature_icon' => esc_html__( 'Feature Icon', 'webar-addons' ),
						'about_feature_title' => esc_html__( 'SMM Marketing', 'webar-addons' ),
						'about_feature_desc' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry', 'webar-addons' ),
					],

					[
						'about_feature_icon' => esc_html__( 'Feature Icon', 'webar-addons' ),
						'about_feature_title' => esc_html__( 'Ecommerce Solution', 'webar-addons' ),
						'about_feature_desc' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry', 'webar-addons' ),
					]
					
				],
				'title_field' => '{{{ about_feature_title }}}',
			]
		);

		$this->end_controls_section();

		//About Style control Start
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'About Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_control(
			'about_title_color',
			[
				'label' => esc_html__( 'Title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					// '{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .page-title h4' => 'color: {{VALUE}}',
				],
				'default' => '#635cdb'
			]
		);

		//Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'about_title_typography',
				'selector' => '{{WRAPPER}} .page-title h4',
			]
		);

		//About Border color
		$this->add_control(
			'about_border_color',
			[
				'label' => esc_html__( 'Border Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					// '{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .page-title h4:before' => 'background-color: {{VALUE}}',
				],
				'default' => '#635CDB'
			]
		);



		//About border width
		$this->add_control(
			'width',
			[
				'label' => esc_html__( 'Border Width', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 51,
				],
				'selectors' => [
					'{{WRAPPER}} .page-title h4:before' => 'width: {{SIZE}}{{UNIT}};',
				
				],
			]
		);

		$this->add_control(
			'height',
			[
				'label' => esc_html__( 'Border Height', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .page-title h4:before' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		//Simple Divider
		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

		
		//About Desc Color
		$this->add_control(
			'about_desc_color',
			[
				'label' => esc_html__( 'Description Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					// '{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .about p' => 'color: {{VALUE}}',
				],
				'default' => '#333'
			]
		);
		
		//About Desc Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'about_desc_typography',
				'selector' => '{{WRAPPER}} .about p',
			]
		);

		//About Button Control Start
		$this->add_control(
			'about_btn',
			[
				'label' => esc_html__( 'About Button', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		
		$this->add_control(
			'about_btn_bg_color',
			[
				'label' => esc_html__( 'Button Background Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					// '{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} a.box-btn' => 'background-color: {{VALUE}}',
				],
				'default' => '#635CDB'
			]
		);
		
		$this->add_control(
			'about_btn_color',
			[
				'label' => esc_html__( 'Button Text Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					// '{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} a.box-btn' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);

		//Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'about_btn_typography',
				'selector' => '{{WRAPPER}} .about a',
			]
		);

		//Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'label' => esc_html__( 'Border', 'webar-addons' ),
				'selector' => '{{WRAPPER}} .box-btn',
			]
		);

		$this->add_control(
			'about-btn-padding',
			[
				'label' => esc_html__( 'Padding', 'webar' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} a.box-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'top' => '7',
					'right' => '13',
					'bottom' => '7',
					'left' => '13',
					'unit' => 'px',
					'isLinked' => 'true',
				]
			]
		);

		$this->add_control(
			'about-btn-margin',
			[
				'label' => esc_html__( 'Margin', 'webar' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .about a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			
			]
		);

		//Btn Border radius
		$this->add_control(
			'border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .box-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		//Btn Box Shadow
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Box Shadow', 'webar-addons' ),
				'selector' => '{{WRAPPER}} .box-btn',
			]
		);


		//About feature control start
		$this->add_control(
			'about_feature',
			[
				'label' => esc_html__( 'About Feature', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'about_feature_space_between',
			[
				'type' => \Elementor\Controls_Manager::SLIDER,
				'label' => esc_html__( 'Spacing', 'webar-addons' ),
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 14,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .single_about h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


			//feature border color
			$this->add_control(
				'feature_border_color',
				[
					'label' => esc_html__( 'Border Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single_about h4:before' => 'background-color: {{VALUE}}',
					],
					'default' => '#635CDB'
					
				]
			);

		
		//Color
		$this->add_control(
			'feature_title_color',
			[
				'label' => esc_html__( 'Title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single_about h4' => 'color: {{VALUE}}',
				],
				'default' => '#333'
				
			]
		);

		//Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'feature_title_typography',
				'selector' => '{{WRAPPER}} .single_about h4',
			]
		);

		//Feature Description color
		$this->add_control(
			'feature_description_color',
			[
				'label' => esc_html__( 'Description Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single_about p' => 'color: {{VALUE}}',
				],
				'separator' => 'before',
				'default' => '#333'
				
			]
		);

			//Feature description Typography
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'feature_description_typography',
					'selector' => '{{WRAPPER}} .single_about p',
				]
			);

		//feature icon color
		$this->add_control(
			'feature_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single_about i' => 'color: {{VALUE}}',
				],
				'default' => '#635CDB'
				
			]
		);

		//feature icon hover color
		$this->add_control(
			'feature_icon_hover_color',
			[
				'label' => esc_html__( 'Icon Hover Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single_about:hover i' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
				
			]
		);

		

		$this->end_controls_section();

	
    }

	//Content rendering ‍Start
    protected function render() {
        $settings = $this->get_settings_for_display();

		$about_title = $settings['about_title'];
		$about_desc = $settings['about_desc'];
		$about_btn_text = $settings['about_btn_text'];
		$about_btn_url = $settings['about_btn_url'];
		$about_feature_list = $settings['about_feature_list'];

	?>

			<div class="row">
               <div class="col-md-7">
                  <div class="about">
                     <div class="page-title">
                        <h4> <?php echo $about_title; ?> </h4>
                     </div>
                     <p> <?php echo $about_desc; ?> </p>
                     
                     <a href="<?php echo $about_btn_url; ?>" class="box-btn"> <?php echo $about_btn_text; ?> <i class="fa fa-angle-double-right"></i></a>
                  </div>
               </div>
               <div class="col-md-5">
				   <?php
				   		foreach($about_feature_list as $feature_list) {

						?>
							<div class="single_about">
								<i class="<?php echo $feature_list['about_feature_icon']['value']; ?>"></i>
								<h4> <?php echo $feature_list['about_feature_title']; ?> </h4>
								<p> <?php echo $feature_list['about_feature_desc']; ?> </p>
							</div>
						<?php
						   } 
				   ?>
               	</div>
            </div>


	<?php
		
    }
}