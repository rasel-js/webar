<?php

class Webar_Blog_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'blog_widget';
	}

	public function get_title() {
		return esc_html__( 'WE Blog', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'blog', 'post' ];
	}

    protected function register_controls() {

        // Content Tab
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'blog_column',
			[
				'label' => esc_html__( 'Select Column', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'col-md-4 col-sm-6',
				'options' => [
					'col-md-4 col-sm-6'  => esc_html__( '3 Column', 'webar-addons' ),
					'col-md-6 col-sm-6' => esc_html__( '2 Column', 'webar-addons' ),
					'col-md-3 col-sm-6' => esc_html__( '4 Column', 'webar-addons' ),
					
				],
			]
		);

        $this->add_control(
			'p_per_page',
			[
				'label' => esc_html__( 'Post Per Page', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 50000,
				'step' => 1,
				'default' => 6,
			]
		);

        $this->add_control(
			'blog_order',
			[
				'label' => esc_html__( 'Order', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC'  => esc_html__( 'ASC', 'webar-addons' ),
					'DESC' => esc_html__( 'DESC', 'webar-addons' ),
					'unknown' => esc_html__( 'Unknown', 'webar-addons' ),
				],
			]
		);

        $this->add_control(
			'blog_orderby',
			[
				'label' => esc_html__( 'Order By', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
                    'date' => esc_html__( 'Date', 'webar-addons' ),
                    'title' => esc_html__( 'Title', 'webar-addons' ),
					'author'  => esc_html__( 'Author', 'webar-addons' ),
					'rand' => esc_html__( 'Random', 'webar-addons' ),
                    'comment_count' => esc_html__( 'Comment Count', 'webar-addons' ),
					'none' => esc_html__( 'None', 'webar-addons' ),
					
				],
			]
		);

        $this->add_control(
			'show_date',
			[
				'label' => esc_html__( 'Publish Date', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Hide', 'webar-addons' ),
				'label_off' => esc_html__( 'Show', 'webar-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'show_author',
			[
				'label' => esc_html__( 'Author Name', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Hide', 'webar-addons' ),
				'label_off' => esc_html__( 'Show', 'webar-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'show_btn',
			[
				'label' => esc_html__( 'Button', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Hide', 'webar-addons' ),
				'label_off' => esc_html__( 'Show', 'webar-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_control(
			'show_excerpt',
			[
				'label' => esc_html__( 'Excerpt', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Hide', 'webar-addons' ),
				'label_off' => esc_html__( 'Show', 'webar-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->end_controls_section();



        //*** Style Tab start *****************************************
        //*** Style Tab start *****************************************
		$this->start_controls_section(
			'blog_style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'blog_title_color',
			[
				'label' => esc_html__( 'Title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-title h4 a' => 'color: {{VALUE}}',
                'default' => '$333'
				],
                'separator' => 'before'
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'blog_title_typography',
				'selector' => '{{WRAPPER}} .post-title h4 a',
			]
		);

        $this->add_control(
			'blog_title_text_align',
			[
				'label' => esc_html__( 'Alignment', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'webar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'webar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'webar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
					'{{WRAPPER}} .post-title h4' => 'text-align: {{VALUE}}',
				],
			]
		);

       

        $this->add_control(
			'blog_meta_color',
			[
				'label' => esc_html__( 'Meta Text Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pots-meta ul li a' => 'color: {{VALUE}}',
                'default' => '$333'
				],
                'separator' => 'before'
                
			]
		);


        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'blog_meta_typography',
				'selector' => '{{WRAPPER}} .pots-meta ul li a',
			]
		);

        // Slash style start
        $this->add_control(
			'blog_meta_slase_color',
			[
				'label' => esc_html__( 'Slash Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pots-meta ul li:before' => 'color: {{VALUE}}',
                'default' => '$333'
				],
                
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'blog_slase_typography',
				'selector' => '{{WRAPPER}} .pots-meta ul li:before',
			]
		);
        // Slash style end

        $this->add_control(
			'blog_meta_text_align',
			[
				'label' => esc_html__( 'Alignment', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'webar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'webar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'webar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
					'{{WRAPPER}} .pots-meta ul' => 'text-align: {{VALUE}}',
				],
			]
		);

        //Meta border

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'meta_border',
				'label' => esc_html__( 'Border', 'webar-addons' ),
				'selector' => '{{WRAPPER}} .pots-meta',
			]
		);
        // $this->add_control(
		// 	'meta_border',
		// 	[
		// 		'label' => esc_html__( 'Border', 'webar-addons' ),
		// 		'type' => \Elementor\Controls_Manager::SLIDER,
		// 		'size_units' => [ 'px' ],
		// 		'range' => [
		// 			'px' => [
		// 				'min' => 0,
		// 				'max' => 10,
		// 				'step' => 1,
		// 			],
					
		// 		],
		// 		'default' => [
		// 			'unit' => 'px',
		// 			'size' => 1,
		// 		],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .pots-meta' => 'border-bottom: {{SIZE}}{{UNIT}};',
		// 		],
		// 	]
		// );

        // $this->add_control(
		// 	'meta_border_color',
		// 	[
		// 		'label' => esc_html__( 'Border Color', 'webar-addons' ),
		// 		'type' => \Elementor\Controls_Manager::COLOR,
		// 		'selectors' => [
		// 			'{{WRAPPER}} .pots-meta' => 'border-bottom: {{VALUE}}',
		// 		],
        //         'default' => '#333'
		// 	]
		// );

        //excerpt style
        $this->add_control(
			'blog_excerpt_color',
			[
				'label' => esc_html__( 'Excerpt Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-content p' => 'color: {{VALUE}}',
                'default' => '$333'
				],
                'separator' => 'before'
                
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'blog_excerpt_typography',
				'selector' => '{{WRAPPER}} .post-content p',
			]
		);

        $this->add_control(
			'blog_excerpt_text_align',
			[
				'label' => esc_html__( 'Alignment', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'webar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'webar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'webar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
					'{{WRAPPER}} .post-content p' => 'text-align: {{VALUE}}',
				],
			]
		);

        //Blog Button Control Start
		$this->add_control(
			'blog_btn',
			[
				'label' => esc_html__( 'Button Style', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
                'condition' => [
                    'show_btn' => 'yes'
                ],
                'separator' => 'before'
			]
		);

      

		$this->add_control(
			'blog_btn_color',
			[
				'label' => esc_html__( 'Background Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					// '{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} a.box-btn' => 'background-color: {{VALUE}}',
				],
				'default' => '#635CDB',
                'condition' => [
					'show_btn' => 'yes'
				]
			]
		);

		//Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'blog_btn_typography',
				'selector' => '{{WRAPPER}} a.box-btn',
                'condition' => [
					'show_btn' => 'yes'
				]
			]
		);

		//Border
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn_border',
				'label' => esc_html__( 'Border', 'webar-addons' ),
				'selector' => '{{WRAPPER}} a.box-btn',
                'condition' => [
					'show_btn' => 'yes'
				]
			]
		);

		//Btn Border radius
		$this->add_control(
			'border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.box-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
					'show_btn' => 'yes'
				]
			]
		);

		//Btn Box Shadow
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Box Shadow', 'webar-addons' ),
				'selector' => '{{WRAPPER}} a.box-btn',
                'condition' => [
					'show_btn' => 'yes'
				]
			]
		);

        $this->add_responsive_control(
			'btn_padding',
			[
				'label' => esc_html__( 'Padding', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.box-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
					'show_btn' => 'yes'
				]
			]
		);

        $this->add_control(
			'text_align',
			[
				'label' => esc_html__( 'Alignment', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'webar-addons' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'webar-addons' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'webar-addons' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'left',
				'toggle' => true,
                'selectors' => [
					'{{WRAPPER}} h3' => 'text-align: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'button_margin',
			[
				'label' => esc_html__( 'Button Margin', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.box-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
                'separator' => 'before',
                'condition' => [
					'show_btn' => 'yes'
				]
			]
		);

   

        $this->end_controls_section();

    }




    //Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$blog_column = $settings['blog_column'];
		$blog_order = $settings['blog_order'];
		$blog_orderby = $settings['blog_orderby'];
		$p_per_page = $settings['p_per_page'];

		$blog_date = $settings['show_date'];
		$blog_author = $settings['show_author'];
		$blog_btn = $settings['show_btn'];
		$blog_excerpt = $settings['show_excerpt'];

	

       


	
        if($blog_column == 'col-md-4 col-sm-4') {
            $blog_column = 'col-md-4 col-sm-4';
        } elseif($blog_column == 'col-md-6 col-sm-6') {
            $blog_column = 'col-md-6 col-sm-6';
        } elseif($blog_column == 'col-md-3 col-sm-6') {
            $blog_column = 'col-md-3 col-sm-6';
        }
        
	    ?>
			<div class="row">
                <?php
                    $args = [
                        'post_type'         => 'post',
                        'posts_per_page'    => $p_per_page,
                        'order'             => $blog_order,
                        'orderby'           => $blog_orderby,
                        
                        
                    ];
                    $query = new WP_Query($args);
                    while($query->have_posts()) {
                        $query->the_post();
                        ?>
                        
                            <div class="<?php echo $blog_column; ?>">
                                <div class="single-blog">
                                    <img src="<?php echo the_post_thumbnail_url('webar-image-size'); ?>" alt="<?php echo the_title(); ?>">
                                    

                                    <div class="post-content">
                                        <div class="post-title">
                                        <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                        </div>
                                        <div class="pots-meta">
                                        <ul>
                                            <?php 
                                                if($blog_date == 'yes') {
                                                    ?>
                                                        <li><a href=""><?php echo get_the_date(); ?></a></li>
                                                    <?php
                                                }
                                            ?>

                                            <?php 
                                                if($blog_author == 'yes') {
                                                    ?>
                                                        <li><a href="#"><?php the_author(); ?></a></li>
                                                    <?php
                                                }
                                            ?>
                                            
                                        </ul>
                                        </div>
                                        <?php 
                                                if($blog_excerpt == 'yes') {
                                                    ?>
                                                        <p><?php the_excerpt(); ?></p>
                                                    <?php
                                                }
                                        ?>


                                            <?php 
                                                $elementClass = 'container';
                                                if ( $settings['hover_animation'] ) {
                                                    $elementClass .= ' elementor-animation-' . $settings['hover_animation'];
                                                }
                                                $this->add_render_attribute( 'wrapper', 'class', $elementClass );
                                            ?>

                                        
                                        <?php 

                                                if($blog_btn == 'yes') {
                                                    ?>
                                                        <h3 <?php echo esc_attr( $settings['text_align'] ); ?> <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
                                                        <a href="<?php the_permalink(); ?>" class="box-btn">read more <i class="fa fa-angle-double-right"></i></a> </h3>
                                                    <?php
                                                }
                                        ?>
                                        
                                    </div>
                                </div>
                            </div>

                        <?php
                    }
                    wp_reset_postdata();
                ?>
              
            </div>

	    <?php
		
    }


}




