<?php

class Elementor_Contact_Info_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'contact_info_widget';
	}

	public function get_title() {
		return esc_html__( 'Contact Info', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-info-box';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'info', 'contact' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Contact Info', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ** All controls start
	
		$this->add_control(
			'info_icon',
			[
				'label' => esc_html__( 'Icon', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
	
		$this->add_control(
			'info_title',
			[
				'label' => esc_html__( 'Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Email', 'webar-addons' ),
				
			]
		);

		$this->add_control(
			'info_subtitle',
			[
				'label' => esc_html__( 'Sub Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Info@Demo.Com', 'webar-addons' ),
				
			]
		);


		
		
        $this->end_controls_section();


		//Style control start ***********************************************
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		//service icon color
		$this->add_control(
			'contact_info_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .contact-address i' => 'color: {{VALUE}}',
				],
				'default' => '#fff',
				'separator' => 'before'
			]
		);

			//service icon bg color
			$this->add_control(
				'contact_info_icon_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .contact-address i' => 'background-color: {{VALUE}}',
					],
					'default' => '#635CDB',
					
				]
			);

			//Icon border radius
			$this->add_control(
				'info_icon_radius',
				[
					'label' => esc_html__( 'Border Radius', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors' => [
						'{{WRAPPER}} .contact-address i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					
				]
			);

			//Icon size
			$this->add_responsive_control(
				'info_icon_size',
				[
					'label' => esc_html__( 'Icon Size', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 80,
							'step' => 1,
						],
						
					],
					'default' => [
						'unit' => 'px',
						'size' => 15,
					],
					'selectors' => [
						'{{WRAPPER}} .contact-address i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
					
				]
			);

				//Icon pading
				$this->add_responsive_control(
					'info_icon_padding',
					[
						'label' => esc_html__( 'Icon Padding', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::SLIDER,
						'size_units' => [ 'px' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 140,
								'step' => 1,
							],
							
						],
						'default' => [
							'unit' => 'px',
							'size' => 45,
						],
						'selectors' => [
							'{{WRAPPER}} .contact-address i' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
						],
						
						
					]
				);

				$this->add_control(
					'info_title_color',
					[
						'label' => esc_html__( 'Title Color', 'plugin-name' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .contact-address h4' => 'color: {{VALUE}}',
						],
						'default' => '#333333',
						'separator' => 'before'
					]
				);

				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'info_title_typography',
						'selector' => '{{WRAPPER}} .contact-address h4',
					]
				);

				$this->add_control(
					'info_sub_title',
					[
						'label' => esc_html__( 'Sub Title Color', 'plugin-name' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .contact-address h4 span' => 'color: {{VALUE}}',
						],
						'default' => '#333333'
						
					]
				);

				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'info_sub_title_typography',
						'selector' => '{{WRAPPER}} .contact-address h4 span',
					]
				);



		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$info_icon = $settings['info_icon'];
		$info_title = $settings['info_title'];
		$info_subtitle = $settings['info_subtitle'];
		

	?>

			<div class="contact-address">
                <i class="<?php echo $info_icon['value']; ?>"></i>
                <h4><?php echo $info_title; ?> <span><?php echo $info_subtitle; ?></span></h4>
            </div>			


	<?php
		
    }
}



