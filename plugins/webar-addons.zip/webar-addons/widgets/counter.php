<?php

class Elementor_Counter_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'counter_widget';
	}

	public function get_title() {
		return esc_html__( 'We Counter', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-counter';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'counter', 'countdown' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ********** All controls start
		//Counter Column
		$this->add_control(
			'counter_column',
			[
				'label' => esc_html__( 'Select Column', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'columnFour',
				'options' => [
					'columnThree'  => esc_html__( '3 Column', 'webar-addons' ),
					'columnFour' => esc_html__( '4 Column', 'webar-addons' ),
					'columnTwo' => esc_html__( '2 Column', 'webar-addons' ),
					
				],
			]
		);
		

		//Counter list repeter
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'counter_icon', [
				'label' => esc_html__( 'Icon', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$repeater->add_control(
			'counter_number', [
				'label' => esc_html__( 'Number', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => esc_html__( 'List Content' , 'webar-addons' ),
				'show_label' => true,
				'default' => 65
			]
		);

		$repeater->add_control(
			'counter_title',
			[
				'label' => esc_html__( 'Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Clients', 'webar-addons' ),
				
			]
		);

		// $repeater->add_control(
		// 	'counter-background-color',
		// 	[
		// 		'label' => esc_html__( 'Background Color', 'webar-addons' ),
		// 		'type' => \Elementor\Controls_Manager::COLOR,
		// 		'selectors' => [
		// 			'{{WRAPPER}} .counter-area .col-md-3' => 'background-color: {{VALUE}}'
		// 		],
		// 	]
		// );

		$this->add_control(
			'counters',
			[
				'label' => esc_html__( 'Counter List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'webar-addons' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'webar-addons' ),
					],
					// [
					// 	'list_title' => esc_html__( 'Title #2', 'webar-addons' ),
					// 	'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'webar-addons' ),
					// ],
				],
				'title_field' => '{{{ counter_title }}}',
			]
		);

	
		
        $this->end_controls_section();



		//******** counter style start */
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			//Counter  start
			$this->add_control(
				'counter_box_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-counter' => 'background-color: {{VALUE}}',
					],
					'default' => '#292e47'
				]
			);

		
		$this->add_control(
			'counter_title_color',
			[
				'label' => esc_html__( 'Title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-counter h4' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'counter_title_typography',
				'selector' => '{{WRAPPER}} .single-counter h4',
			]
		);
		
		//Counter number start
		$this->add_control(
			'counter_count_color',
			[
				'label' => esc_html__( 'Number Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-counter h4 span' => 'color: {{VALUE}}',
				],
				'default' => '#fff',
				'separator' => 'before'
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'counter_count_typography',
				'selector' => '{{WRAPPER}} .single-counter h4 span',
			]
		);

		//Icon color
		$this->add_control(
			'counter_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-counter i' => 'color: {{VALUE}}',
				],
				'separator' => 'before',
				'default' => '#fff'
			]
		);

		$this->add_control(
			'counter_icon_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-counter i' => 'background-color: {{VALUE}}',
				],
				'default' => '#635CDB'
			]
		);
		
		
	
		


		

		


		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$counter_column = $settings['counter_column'];
		$counters = $settings['counters'];
		// $section_desc = $settings['section_desc'];
		if($counter_column == 'columnFour') {
			$counter_column = 'col-lg-3';
		} elseif($counter_column == 'columnThree') {
			$counter_column = 'col-lg-4';
		} elseif($counter_column == 'columnTwo') {
			$counter_column = 'col-lg-6';
		} else {

		}

	?>

			<div class="row no-space">
				<?php 
					foreach($counters as $counter) {
						?>
							<div class="<?php echo $counter_column; ?>">
								<div class="single-counter">
									<h4><i class="<?php echo $counter['counter_icon']['value'];?>"></i><span class="counter"><?php echo $counter['counter_number'];?></span><?php echo $counter['counter_title'];?></h4>
								</div>
							</div>
						
						<?php
					}
				
				?>
            </div>


	<?php
		
    }
}