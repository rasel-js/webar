<?php

class Elementor_Faq_Skills_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'faq_skills_widget';
	}

	public function get_title() {
		return esc_html__( 'Faq Skills', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-skill-bar';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'kaq', 'skills' ];
	}

    protected function register_controls(){

		//Faq content
        $this->start_controls_section(
			'faq_section',
			[
				'label' => esc_html__( 'Faq Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ** All controls start
	
		//Faq title
		$this->add_control(
			'faq_title',
			[
				'label' => esc_html__( 'Faq Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'FAQ', 'webar-addons' ),
				'placeholder' => esc_html__( 'Type your title', 'webar-addons' ),
				'show_label'  => true,
				'separator'   => 'before'
			]
		);


		//Repeater controll - Faq section
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'accordion_title', [
				'label' => esc_html__( 'Accordion Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Your Title Here' , 'webar-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'accordion_desc', [
				'label' => esc_html__( 'Accordion Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard' , 'webar-addons' ),
				'show_label' => false,
			]
		);

		// $repeater->add_control(
		// 	'list_color',
		// 	[
		// 		'label' => esc_html__( 'Color', 'webar-addons' ),
		// 		'type' => \Elementor\Controls_Manager::COLOR,
		// 		'selectors' => [
		// 			'{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
		// 		],
		// 	]
		// );

		$this->add_control(
			'faq_list',
			[
				'label' => esc_html__( 'FAQ List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'accordion_title' => esc_html__( 'Title #1', 'webar-addons' ),
						'accordion_desc' => esc_html__( 'Item content. Click the edit button to change this text.', 'webar-addons' ),
					],
					[
						'accordion_title' => esc_html__( 'Title #2', 'webar-addons' ),
						'accordion_desc' => esc_html__( 'Item content. Click the edit button to change this text.', 'webar-addons' ),
					],
					[
						'accordion_title' => esc_html__( 'Title #3', 'webar-addons' ),
						'accordion_desc' => esc_html__( 'Item content. Click the edit button to change this text.', 'webar-addons' ),
					]
				],
				'title_field' => '{{{ accordion_title }}}',
			]
		);

		
        $this->end_controls_section();

		//Skills section
		$this->start_controls_section(
			'skills_section',
			[
				'label' => esc_html__( 'Skills Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		//Skills title
		$this->add_control(
			'skills_title',
			[
				'label' => esc_html__( 'Skills Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Our Skills', 'webar-addons' ),
				'placeholder' => esc_html__( 'Type your title', 'webar-addons' ),
				'show_label'  => true,
				'separator'   => 'before'
			]
		);


		//Repeater controll - Skills section
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'skill_list_title', [
				'label' => esc_html__( 'Skill List Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'HTML5' , 'webar-addons' ),
				
			]
		);

		$repeater->add_control(
			'skill_list_number', [
				'label' => esc_html__( 'Skill List %', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 80,
				
			]
		);

		// $repeater->add_control(
		// 	'list_color',
		// 	[
		// 		'label' => esc_html__( 'Color', 'webar-addons' ),
		// 		'type' => \Elementor\Controls_Manager::COLOR,
		// 		'selectors' => [
		// 			'{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
		// 		],
		// 	]
		// );

		$this->add_control(
			'skill_list',
			[
				'label' => esc_html__( 'Skill List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'skill_list_title' => esc_html__( 'HTML5', 'webar-addons' ),
						'skill_list_number' => 80,
					],
					[
						'skill_list_title' => esc_html__( 'CSS3', 'webar-addons' ),
						'skill_list_number' => 75,
					],
					[
						'skill_list_title' => esc_html__( 'JavaScript', 'webar-addons' ),
						'skill_list_number' => 70,
					]
				
				],
				'title_field' => '{{{ skill_list_title }}}',
			]
		);

		$this->end_controls_section();


		//Style control start
		$this->start_controls_section(
			'faq_style_section',
			[
				'label' => esc_html__( 'Faq & Skills', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		// Ui control heading
		$this->add_control(
			'sub_title_heading',
			[
				'label' => esc_html__( 'Faq & Skill Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

			// Ui control heading
			// $this->add_control(
			// 	'border_color',
			// 	[
			// 		'label' => esc_html__( 'Border color', 'webar-addons' ),
			// 		'type' => \Elementor\Controls_Manager::HEADING,
			// 		'separator' => 'before',
			// 	]
			// );

			//Faq title color
			$this->add_control(
				'faq_skill_title_color',
				[
					'label' => esc_html__( 'Title Color', 'plugin-name' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .page-title h4' => 'color: {{VALUE}}',
					],
					'default' => '#fff'
				]
			);

			//Faq title Typography control
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'content_typography',
					'selector' => '{{WRAPPER}} .page-title h4',
				]
			);

			//Border color control
			$this->add_control(
				'border_color_control',
				[
					'label' => esc_html__( 'Border Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .page-title h4:before' => 'background-color: {{VALUE}}',
					],
					'default' => '#635CDB'
				]
			);

	

			// Ui control heading
			$this->add_control(
				'main_title_heading',
				[
					'label' => esc_html__( 'Faq List', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

				//Faq list title color
				$this->add_control(
					'faq_list_title_color',
					[
						'label' => esc_html__( 'Title Color', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .card-header .btn' => 'color: {{VALUE}}',
						],
						'default' => '#fff'
					]
				);

				//Faq list title color
				$this->add_control(
					'faq_list_bg_color',
					[
						'label' => esc_html__( 'Background Color', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .card-header' => 'background-color: {{VALUE}}',
						],
						'default' => '#5e56e6'
					]
				);

				//Faq list title typography
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'title_typography',
						'selector' => '{{WRAPPER}} .card-header .btn',
					]
				);


				//Faq list desc color
				$this->add_control(
					'faq_list_desc_color',
					[
						'label' => esc_html__( 'Description Color', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .card-body' => 'color: {{VALUE}}',
						],
						'default' => '#333',
						'separator' => 'before'
					]
				);

				
				//Faq list desc color
				$this->add_control(
					'faq_list_desc_bg_color',
					[
						'label' => esc_html__( 'Background Color', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .card' => 'background-color: {{VALUE}}',
						],
						'default' => '#fff',
						
					]
				);

				//Faq list desc typography
				$this->add_group_control(
					\Elementor\Group_Control_Typography::get_type(),
					[
						'name' => 'list_desc_typography',
						'selector' => '{{WRAPPER}} .card-body',
					]
				);

	
			//*** All Skills controll */
			// Ui control heading
			$this->add_control(
				'skill_list_ui_heading',
				[
					'label' => esc_html__( 'Skill List', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			//Skill title color
			$this->add_control(
				'skill_title_color',
				[
					'label' => esc_html__( 'Title Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-skill h4' => 'color: {{VALUE}}',
					],
					'default' => '#fff'
				]
			);

		//Skill Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'skill_title_typography',
				'selector' => '{{WRAPPER}} .single-skill h4',
			]
		);

			//skill prgressbar color
			$this->add_control(
				'skill_progress_color',
				[
					'label' => esc_html__( 'Progress Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-skill .progress-bar' => 'background-color: {{VALUE}}',
					],
					'default' => '#635CDB'
				]
			);

				//skill number color
				$this->add_control(
					'skill_number_color',
					[
						'label' => esc_html__( 'Number Color', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .single-skill .progress-bar' => 'color: {{VALUE}}',
						],
						'default' => '#fff'
					]
				);

				//Skill number Typography
					$this->add_group_control(
						\Elementor\Group_Control_Typography::get_type(),
						[
							'name' => 'skill_number_typography',
							'selector' => '{{WRAPPER}} .single-skill .progress-bar',
						]
					);

				//Btn Border radius
				$this->add_control(
					'progress_border-radius',
					[
						'label' => esc_html__( 'Border Radius', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .single-skill .progress-bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);

		


		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$faq_title = $settings['faq_title'];
		$faq_list = $settings['faq_list'];
		$skills_title = $settings['skills_title'];
		$skill_list = $settings['skill_list'];
		// $section_desc = $settings['section_desc'];

	?>

			<div class="row">
               <div class="col-md-6">
                  <div class="faq">
                     <div class="page-title">
                        <h4> <?php echo $faq_title; ?> </h4>
                     </div>
                     <div class="accordion" id="accordionExample">
						 <?php
						 	$i = 0;
						 	foreach($faq_list as $faq_lists) {
							$i++;
								?>

									<div class="card">
										<div class="card-header" id="heading<?php echo $i; ?>">
											<h5 class="mb-0">
												<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo $i; ?>" aria-expanded="true" aria-controls="collapseOne">
												<?php echo $faq_lists['accordion_title']; ?>
												</button>
											</h5>
										</div>
										<div id="collapse<?php echo $i; ?>" class="collapse <?php if($i==1) {echo 'show';} ?>" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<?php echo $faq_lists['accordion_desc']; ?>
											</div>
										</div>
									</div>

								<?php
							 } 
						 ?>
                       
                       
                     </div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="skills">
                     <div class="page-title">
                        <h4> <?php echo $skills_title; ?> </h4>
                     </div>
					 <?php 
					 	foreach($skill_list as $skill_lists) {

						?>

							<div class="single-skill">
								<h4> <?php echo $skill_lists['skill_list_title']; ?> </h4>
								
								<div class="progress-bar" role="progressbar" style="width: <?php echo $skill_lists['skill_list_number']; ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"> <?php echo $skill_lists['skill_list_number'];?> %</div>
							</div>



						<?php
						 }
					 ?>



                   
                  </div>
               </div>
            </div>


	<?php
		
    }
}