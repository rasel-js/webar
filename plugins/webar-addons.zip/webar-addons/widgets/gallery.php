<?php

class Elementor_Gallery_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'gallery_widget';
	}

	public function get_title() {
		return esc_html__( 'WE Gallery', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'gallery', 'grid' ];
	}

    protected function register_controls(){

		//Gallery setting Tab content
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'gallery_column',
			[
				'label' => esc_html__( 'Select Column ', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'col-xl-4',
				'options' => [
					'col-xl-4'  => esc_html__( '3 Column', 'webar-addons' ),
					'col-xl-6' => esc_html__( '2 Column', 'webar-addons' ),
					'col-xl-3' => esc_html__( '4 Column', 'webar-addons' ),
					
				],
				'separator' => 'before'
				
			]
		);

		$this->add_control(
			'gallery_lightbox',
			[
				'label' => esc_html__( 'Light Box', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Off', 'webar-addons' ),
				'label_off' => esc_html__( 'On', 'webar-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ** All controls start
	
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'gallery_title', [
				'label' => esc_html__( 'Gallery Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'webar-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'gallery_main_image',
			[
				'label' => esc_html__( 'Main Image', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'gallery_big_image',
			[
				'label' => esc_html__( 'Popup Image', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				
				
			]
			
		);
	

		$this->add_control(
			'gallery_list',
			[
				'label' => esc_html__( 'Gallery List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'webar-addons' ),
					
					],
					[
						'list_title' => esc_html__( 'Title #2', 'webar-addons' ),
						
					],
				],
				'title_field' => '{{{ gallery_title }}}',
				'separator' => 'before'
			]
		);

		$this->end_controls_section();

		

		//Style control
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

	

		


		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$gallery_list = $settings['gallery_list'];
		$gallery_column = $settings['gallery_column'];
		$gallery_lightbox = $settings['gallery_lightbox'];
		
		if($gallery_column == 'col-xl-4') {
			$gallery_column == 'col-xl-4';
		} elseif($gallery_column == 'col-xl-3') {
			$gallery_column == 'col-xl-3';
		} elseif($gallery_column == 'col-xl-6') {
			$gallery_column == 'col-xl-6';
		}
	?>

		<div class="row">
           <?php 
		 		foreach($gallery_list as $gallery) {
					?>
						<div class="<?php echo $gallery_column; ?>">
							<div class="single-gallery">
								<img src="<?php echo $gallery['gallery_main_image']['url']; ?>" alt="<?php echo $gallery['gallery_title']; ?>">
								<div class="gallery-hover">
									<div class="gallery-content">
										<?php 
											if($gallery_lightbox == 'yes') {
												?>
													<h3><a href="<?php echo $gallery['gallery_big_image']['url']; ?>" class="gallery"><i class="fa fa-plus"></i> <?php echo $gallery['gallery_title']; ?></a></h3>
												<?php
											} else {
												?>
													<h3><a><?php echo $gallery['gallery_title']; ?></a></h3>
												<?php
											}
										?>
									
									</div>
								</div>
							</div>
           				</div>
					<?php
				}  
		   ?>
            
        </div>


	<?php
		
    }
}