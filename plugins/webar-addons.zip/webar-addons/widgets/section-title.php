<?php

class Elementor_Section_Title_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'section_title_widget';
	}

	public function get_title() {
		return esc_html__( 'Section Title', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-heading';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'text', 'heading' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ** All controls start
	
		// Section Sub-title
		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Section Subtitle', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'who we are?', 'webar-addons' ),
				'placeholder' => esc_html__( 'Type your Sub-title', 'webar-addons' ),
				'show_label'  => true,
				'separator'   => 'before'
			]
		);

		// Section Title
		$this->add_control(
			'main_title',
			[
				'label' => esc_html__( 'Section Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'ABOUT US', 'webar-addons' ),
				'placeholder' => esc_html__( 'Type your Title', 'webar-addons' ),
				'show_label'  => true,
				'separator'   => 'before'
			]
		);

		// Section Description
		$this->add_control(
			'section_desc',
			[
				'label' => esc_html__( 'Section Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.', 'webar-addons' ),
				'placeholder' => esc_html__( 'Type your Description', 'webar-addons' ),
				'show_label'  => true,
				'separator'   => 'before'
			]
		);



		
		
        $this->end_controls_section();

		//Style control
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
			]
		);


			// Ui control heading
			$this->add_control(
				'border_color',
				[
					'label' => esc_html__( 'Border color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			//Boder color control
			$this->add_control(
				'border_color_control',
				[
					'label' => esc_html__( 'Border Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					],
					'default' => '#B0ADEC'
				]
			);

		// Ui control heading
		$this->add_control(
			'sub_title_heading',
			[
				'label' => esc_html__( 'Section Subtitle', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		//Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'selector' => '{{WRAPPER}} .section-title h3 span',
			]
		);

		//Subtitle color control
		$this->add_control(
			'subtitle_color',
			[
				'label' => esc_html__( 'Sub-title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title h3 span' => 'color: {{VALUE}}',
				],
				'default' => '#333333'
			]
		);

			// Ui control heading
			$this->add_control(
				'main_title_heading',
				[
					'label' => esc_html__( 'Section Title', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

		//Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .section-title h3',
			]
		);

		//Title color control
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title h3' => 'color: {{VALUE}}',
				],
				'default' => '#333333'
			]
		);

			// Ui control heading
			$this->add_control(
				'desc_title',
				[
					'label' => esc_html__( 'Section Description', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

		//Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',
				'selector' => '{{WRAPPER}} .section-title p',
			]
		);

		//Description color control
		$this->add_control(
			'desc_color',
			[
				'label' => esc_html__( 'Description Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
				],
				'default' => '#333333'
			]
		);


		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$sub_title = $settings['sub_title'];
		$main_title = $settings['main_title'];
		$section_desc = $settings['section_desc'];

	?>

		

			<div class="row section-title">
               <div class="col-md-6 text-right">
                  <h3><span> <?php echo $sub_title; ?> </span> <?php echo $main_title; ?> </h3>
               </div>
               <div class="col-md-6">
                  <p> <?php echo $section_desc; ?> </p>
               </div>
            </div>


	<?php
		
    }
}