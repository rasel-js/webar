<?php

class Elementor_Services_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'services_widget';
	}

	public function get_title() {
		return esc_html__( 'Services Box', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-layout-settings';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'services', 'box' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ** All controls start

		//Services box column 
		$this->add_control(
			'services_column',
			[
				'label' => esc_html__( 'Select Column', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'columnThree',
				'options' => [
					'columnThree'  => esc_html__( '3 Column', 'webar-addons' ),
					'columnFour' => esc_html__( '4 Column', 'webar-addons' ),
					'columnTwo' => esc_html__( '2 Column', 'webar-addons' ),
					
				],
			]
		);


		//Services box list (repeater controll)
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'service_media_type',
			[
				'label' => esc_html__( 'Select Type', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'service_icon' => [
						'title' => esc_html__( 'Icon', 'webar-addons' ),
						'icon' => 'eicon-external-link-square',
					],
					'service_image' => [
						'title' => esc_html__( 'Image', 'webar-addons' ),
						'icon' => 'eicon-featured-image',
					],
					'service_number' => [
						'title' => esc_html__( 'Number', 'webar-addons' ),
						'icon' => 'eicon-number-field',
					],
				],
				'default' => 'service_icon',
				'toggle' => true,
				'separator' => 'before'
				
			]
		);

		$repeater->add_control(
			'service_icon', [
				'label' => esc_html__( 'Icon', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => [
					'service_media_type' => 'service_icon'
				]
			]
		);

		$repeater->add_control(
			'service_image',
			[
				'label' => esc_html__( 'Choose Image', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'service_media_type' => 'service_image'
				]
			]
		);

		$repeater->add_control(
			'service_number',
			[
				'label' => esc_html__( 'Number', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'default' => 5,
				'condition' => [
					'service_media_type' => 'service_number'
				]
			]
			
		);

		//Service Title
		$repeater->add_control(
			'service_title',
			[
				'label' => esc_html__( 'Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => 'web desgin',
				'separator' => 'before',
				'label_block' => true
				
			]
			
		);

		//Service Description
		$repeater->add_control(
			'service_desc',
			[
				'label' => esc_html__( 'Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry',
				'label_block' => true
				
			]
			
		);

		

		$this->add_control(
			'service_lists',
			[
				'label' => esc_html__( 'Services Box List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'webar-addons' ),
						'list_content' => esc_html__( 'Simple dummy Text.', 'webar-addons' ),
					],
					[
						'list_title' => esc_html__( 'Title #2', 'webar-addons' ),
						'list_content' => esc_html__( 'Simple dummy Text.', 'webar-addons' ),
					],
					[
						'list_title' => esc_html__( 'Title #3', 'webar-addons' ),
						'list_content' => esc_html__( 'Simple dummy Text.', 'webar-addons' ),
					]
				],
				'title_field' => '{{{ service_title }}}',
			]
		);
	
		
	
		
        $this->end_controls_section();


		//********Style TAB Start **************//
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'service_media_style',
			[
				'label' => esc_html__( 'Select Type', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'service_icon_style' => [
						'title' => esc_html__( 'Icon', 'webar-addons' ),
						'icon' => 'eicon-external-link-square',
					],
					'service_image_style' => [
						'title' => esc_html__( 'Image', 'webar-addons' ),
						'icon' => 'eicon-featured-image',
					],
					'service_number_style' => [
						'title' => esc_html__( 'Number', 'webar-addons' ),
						'icon' => 'eicon-number-field',
					],
				],
				'default' => 'service_icon',
				'toggle' => true,
				'separator' => 'before'
				
			]
		);

		//************Service box icon style start */
			//service image type
			$this->add_control(
				'service_image_width',
				[
					'label' => esc_html__( 'Image Size', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 50,
							'max' => 308,
							'step' => 1,
						],
						'%' => [
							'min' => 10,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 200,
					],
					'selectors' => [
						'{{WRAPPER}} .single-service img' => 'width: {{SIZE}}{{UNIT}};',
					],
					'condition' => [
						'service_media_style' => 'service_image_style'
					],
					'separator' => 'before'
				]
			);

			//Image border
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'border',
					'label' => esc_html__( 'Border', 'webar-addons' ),
					'selector' => '{{WRAPPER}} .single-service img',
					'condition' => [
						'service_media_style' => 'service_image_style'
					]
				]

			);

				//Image border radius
				$this->add_control(
					'service_image_border-radius',
					[
						'label' => esc_html__( 'Border Radius', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'selectors' => [
							'{{WRAPPER}} .single-service img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						'condition' => [
							'service_media_style' => 'service_image_style'
						]
					]
				);

				//service image Box Shadow
				$this->add_group_control(
					\Elementor\Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'box_shadow',
						'label' => esc_html__( 'Box Shadow', 'webar-addons' ),
						'selector' => '{{WRAPPER}} .single-service img',
						'condition' => [
							'service_media_style' => 'service_image_style'
						]
					]
				);

					//service image Box hover Shadow
					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'hover_box_shadow',
							'label' => esc_html__( 'Hover Box Shadow', 'webar-addons' ),
							'selector' => '{{WRAPPER}} .single-service img:hover',
							'condition' => [
								'service_media_style' => 'service_image_style'
							]
						]
					);


		//***Service box icon style start */
			//service icon color
			$this->add_control(
				'service_icon_color',
				[
					'label' => esc_html__( 'Icon Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-service i' => 'color: {{VALUE}}',
					],
					'default' => '#fff',
					'condition' => [
						'service_media_style' => 'service_icon_style'
					],
					'separator' => 'before'
				]
			);

				//service icon bg color
				$this->add_control(
					'service_icon_bg_color',
					[
						'label' => esc_html__( 'Background Color', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .single-service i' => 'background-color: {{VALUE}}',
						],
						'default' => '#635CDB',
						'condition' => [
							'service_media_style' => 'service_icon_style'
						]
					]
				);

				//Icon border radius
				$this->add_control(
					'service_icon_border_radius',
					[
						'label' => esc_html__( 'Border Radius', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%' ],
						'selectors' => [
							'{{WRAPPER}} .single-service i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
						'condition' => [
							'service_media_style' => 'service_icon_style'
						]
					]
				);

				//Icon size
				$this->add_responsive_control(
					'service_icon_size',
					[
						'label' => esc_html__( 'Icon Size', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::SLIDER,
						'size_units' => [ 'px' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 80,
								'step' => 1,
							],
							
						],
						'default' => [
							'unit' => 'px',
							'size' => 30,
						],
						'selectors' => [
							'{{WRAPPER}} .single-service i' => 'font-size: {{SIZE}}{{UNIT}};',
						],
						'condition' => [
							'service_media_style' => 'service_icon_style'
						]
					]
				);

					//Icon pading
					$this->add_responsive_control(
						'service_icon_padding',
						[
							'label' => esc_html__( 'Icon Padding', 'webar-addons' ),
							'type' => \Elementor\Controls_Manager::SLIDER,
							'size_units' => [ 'px' ],
							'range' => [
								'px' => [
									'min' => 0,
									'max' => 140,
									'step' => 1,
								],
								
							],
							'default' => [
								'unit' => 'px',
								'size' => 85,
							],
							'selectors' => [
								'{{WRAPPER}} .single-service i' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
							],
							
							'condition' => [
								'service_media_style' => 'service_icon_style'
							]
						]
					);


					//*************Service box number style start */
					//service number color
					$this->add_control(
						'service_number_color',
						[
							'label' => esc_html__( 'Number Color', 'webar-addons' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .single-service span' => 'color: {{VALUE}}',
							],
							'default' => '#333',
							'condition' => [
								'service_media_style' => 'service_number_style'
							],
							'separator' => 'before'
						]
					);
					//Icon typography
					$this->add_group_control(
						\Elementor\Group_Control_Typography::get_type(),
						[
							'name' => 'service_number_typography',
							'selector' => '{{WRAPPER}} .single-service span',
							'condition' => [
								'service_media_style' => 'service_number_style'
							]
						],
						
					);




					/**** Service content */
				// Ui control heading
				$this->add_control(
					'service_content',
					[
						'label' => esc_html__( 'Service Content', 'webar-addons' ),
						'type' => \Elementor\Controls_Manager::HEADING,
						'separator' => 'before',
					]
				);

			//Title color control
			$this->add_control(
				'service_title_color',
				[
					'label' => esc_html__( 'Title Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-service h4' => 'color: {{VALUE}}',
					],
					'default' => '#333'
				]
			);

		//title Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'service_title_typography',
				'selector' => '{{WRAPPER}} .single-service h4',
			]
		);


			//Description color control
			$this->add_control(
				'service_desc_color',
				[
					'label' => esc_html__( 'Description Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-service p' => 'color: {{VALUE}}',
					],
					'default' => '#333',
					'separator' => 'before'
				]
			);

		//Description Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'service_desc_typography',
				'selector' => '{{WRAPPER}} .single-service p',
			]
		);


		// Ui control heading
		$this->add_control(
			'service_box_style',
			[
				'label' => esc_html__( 'Box Style', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		//service box background color control
		$this->add_control(
			'service_box_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-service' => 'background: {{VALUE}}',
				],
				'default' => '#fff',
			]
		);

		//Service box box-shadow
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => '_service_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'webar-addons' ),
				'selector' => '{{WRAPPER}} .single-service'
			]
		);

		//service box border 
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'service_box_border',
				'label' => esc_html__( 'Border', 'webar-addons' ),
				'selector' => '{{WRAPPER}} .single-service',
				'label_block' => false,
			]
		);



		//service box border-radius
		$this->add_control(
			'service-box-border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .single-service' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);





					// Ui control heading
					$this->add_control(
						'service_box_hover',
						[
							'label' => esc_html__( 'Hover Style', 'webar-addons' ),
							'type' => \Elementor\Controls_Manager::HEADING,
							'separator' => 'before',
						]
					);


					//service box background color control
					$this->add_control(
						'service_box_bg_hover_color',
						[
							'label' => esc_html__( 'Background Color', 'webar-addons' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .single-service:hover' => 'background: {{VALUE}}',
							],
							'default' => '#F8B6DD',
						]
					);

				//service box hover border 
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'service_box_hover_border',
						'label' => esc_html__( 'Hover Border', 'webar-addons' ),
						'selector' => '{{WRAPPER}} .single-service:hover',
						
					]
				);


	


		$this->end_controls_section();
    }


	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$services_column_class = $settings['services_column'];
		$service_lists= $settings['service_lists'];
		
		if($services_column_class == 'columnTwo') {
			$services_column_class = 'col-lg-6';
		} elseif($services_column_class == 'columnFour') {
			$services_column_class = 'col-lg-3';
		} else {
			$services_column_class = 'col-lg-4';
		}

	?>

			<div class="row">
				
				<?php 
					foreach($service_lists as $services) {

					?>
						<div class="<?php echo $services_column_class;?> col-md-6">
							<!-- Single Service -->
							<div class="single-service">
								<?php
									if(!empty($services['service_icon']['value'])) {

									?>

									<i class="<?php echo $services['service_icon']['value']?>"></i>

									<?php

									} elseif(!empty($services['service_image']['url'])) {
										
										?>
											<img src="<?php echo $services['service_image']['url'];?>" alt="">
										<?php

									} elseif(!empty($services['service_number'])) {
										?>
											<span><?php echo $services['service_number'];?> </span>
										<?php
									}
								?>
								<!-- <i class="fa fa-laptop"></i> -->
								<h4> <?php echo $services['service_title'];?> </h4>
								<p> <?php echo $services['service_desc'];?> </p>
							</div>
						</div>
					<?php
					}
				
				?>

            </div>


	<?php
		
    }
}