<?php

class Elementor_Slider_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'slider_widget';
	}

	public function get_title() {
		return esc_html__( 'We Slider', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-slider-3d';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'slider', 'carousel' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Slider Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		// ** All controls start

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'slider_image',
			[
				'label' => esc_html__( 'Choose Image', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'slider_subtitle', [
				'label' => esc_html__( 'Subtitle', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Subtitle' , 'webar-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'slider_title', [
				'label' => esc_html__( 'Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'webar-addons' ),
				'label_block' => true,
				'separator' => 'before'
			]
		);

		$repeater->add_control(
			'slider_desc', [
				'label' => esc_html__( 'Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Description' , 'webar-addons' ),
				'show_label' => true,
				'separator' => 'before'
			]
		);

		$repeater->add_control(
			'slider_btn_text', [
				'label' => esc_html__( 'Button Text', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Read More' , 'webar-addons' ),
				'label_block' => true,
				'separator' => 'before'
			]
		);

		$repeater->add_control(
			'slider_btn_url',
			[
				'label' => esc_html__( 'Button URL', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'webar-addons' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
					'separator' => 'before'
				],
			]
		);

		$this->add_control(
			'sliders',
			[
				'label' => esc_html__( 'Sliders List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'slider_subtitle' => esc_html__( 'Slider Subtitle', 'webar-addons' ),
						'slider_title' => esc_html__( 'Slider Title', 'webar-addons' ),
						'slider_desc' => esc_html__( 'Slider Description', 'webar-addons' ),
						'slider_btn_text' => esc_html__( 'Read More. ', 'webar-addons' ),
					],
					[
						'slider_subtitle' => esc_html__( 'Slider Subtitle 1', 'webar-addons' ),
						'slider_title' => esc_html__( 'Slider Title 1', 'webar-addons' ),
						'slider_desc' => esc_html__( 'Slider Description 1', 'webar-addons' ),
						'slider_btn_text' => esc_html__( 'Read More 1', 'webar-addons' ),
					],
				],
				'title_field' => '{{{ slider_title }}}',
			]
		);
	

		$this->end_controls_section();

		//Setting Section Tab
		$this->start_controls_section(
			'setting_section',
			[
				'label' => esc_html__( 'Settings', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'slider_items',
			[
				'label' => esc_html__( 'Items', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 3,
				'step' => 1,
				'default' => 1,
			]
		);

		$this->add_control(
			'slider_autoplay',
			[
				'label' => esc_html__( 'AutoPlay', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'webar-addons' ),
				'label_off' => esc_html__( 'Off', 'webar-addons' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);

        // Slider speed timeout
        $this->add_control(
			'slider_timeout',
			[
				'label' => esc_html__( 'Time Out', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1000,
				'max' => 80000,
				'step' => 1,
				'default' => 3000,
			]
		);

		//Slider dots control
		$this->add_control(
			'slider_dots',
			
			[
				'label' => esc_html__( 'Slider Dots', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'webar-addons' ),
				'label_off' => esc_html__( 'Hide', 'webar-addons' ),
				'return_value' => 'true',
				'default' => 'false'
				
			]
		);


		$this->end_controls_section();


		// Style Tab Control
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		//Slider Subtitle
		$this->add_control(
			'slider_subheading',
			[
				'label' => esc_html__( 'Slider Subtitle', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'slider_subtitle_space',
			[
				'type' => \Elementor\Controls_Manager::SLIDER,
				'label' => esc_html__( 'Spacing', 'webar-addons' ),
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 14,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .slide-tablecell h4' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'slider_subheading_typography',
				'selector' => '{{WRAPPER}} .slide-table h4',
			]
		);

		$this->add_control(
			'slider_subheading_color',
			[
				'label' => esc_html__( 'Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slide-table h4' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);

		$this->add_control(
			'slider_subheading_border',
			[
				'label' => esc_html__( 'Border Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slide-table h4:before' => 'background-color: {{VALUE}}',
				],
				'default' => '#635cdb'
			]
		);

		
		$this->add_responsive_control(
			'slider-border-margin',
			[
				'label' => esc_html__( 'Border Margin', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'default' => [
				
					'isLinked' => false
				],
				
				'selectors' => [
					'{{WRAPPER}} .slide-table h4:before' => 'margin-bottom: {{BOTTOM}}{{UNIT}}; margin-left: {{LEFT}}{{UNIT}};',
				],
			]
		);


			//slider border width
			$this->add_responsive_control(
				'slider_border_width',
				[
					'label' => esc_html__( 'Border Width', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						
						'px' => [
							'min' => 0,
							'max' => 200,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 70,
					],
					'selectors' => [
						'{{WRAPPER}} .slide-table h4:before' => 'width: {{SIZE}}{{UNIT}};',
					
					],
				]
			);


			//slider border height
			$this->add_responsive_control(
				'height',
				[
					'label' => esc_html__( 'Border Height', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						
						'px' => [
							'min' => 0,
							'max' => 200,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 4,
					],
					'selectors' => [
						'{{WRAPPER}} .slide-table h4:before' => 'height: {{SIZE}}{{UNIT}};',
					
					],
				]
			);

		
		// Slider Title
		$this->add_control(
			'slider_title',
			[
				'label' => esc_html__( 'Slider Title', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'slider_title_space',
			[
				'type' => \Elementor\Controls_Manager::SLIDER,
				'label' => esc_html__( 'Spacing', 'webar-addons' ),
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 14,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .slide-table h2' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'slider_title_typography',
				'selector' => '{{WRAPPER}} .slide-table h2',
			]
		);

		$this->add_control(
			'slider_title_color',
			[
				'label' => esc_html__( 'Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slide-table h2' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);

		// Slider Description
		$this->add_control(
			'slider_desc',
			[
				'label' => esc_html__( 'Slider Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'slider_desc_space',
			[
				'type' => \Elementor\Controls_Manager::SLIDER,
				'label' => esc_html__( 'Spacing', 'webar-addons' ),
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 14,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 0,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .slide-table p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'slider_desc_typography',
				'selector' => '{{WRAPPER}} .slide-table p',
			]
		);

		$this->add_control(
			'slider_desc_color',
			[
				'label' => esc_html__( 'Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slide-table p' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);

		// Slider Button control start
		$this->add_control(
			'slider_btn',
			[
				'label' => esc_html__( 'Slider Button', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'slider_btn_typography',
				'selector' => '{{WRAPPER}} .slide-table a',
			]
		);

		$this->add_control(
			'slider_btn_color',
			[
				'label' => esc_html__( 'Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slide-table a' => 'color: {{VALUE}}',
				],
				'default' => '#fff'
			]
		);

		
		$this->add_control(
			'slider_btn_background',
			[
				'label' => esc_html__( 'Background', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slide-table a' => 'background-color: {{VALUE}}',
				],
				'default' => '#635cdb'
			]
		);

		$this->add_control(
			'slider-btn-padding',
			[
				'label' => esc_html__( 'Padding', 'webar' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} a.box-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default' => [
					'top' => '7',
					'right' => '13',
					'bottom' => '7',
					'left' => '13',
					'unit' => 'px',
					'isLinked' => 'true',
				]
			]
		);

		$this->add_control(
			'slider-btn-margin',
			[
				'label' => esc_html__( 'Margin', 'webar' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .slide-tablecell a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			
			]
		);

		//Border radius
		$this->add_control(
			'border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .slide-table a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		// Slider Dots
		$this->add_control(
			'slider_dots_heading',
			[
				'label' => esc_html__( 'Slider Dots', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);


		$this->add_control(
			'slider_dots_color',
			[
				'label' => esc_html__( 'Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .owl-dots div' => 'background-color: {{VALUE}}',
				],
				'default' => '#eee'
			]
		);

		$this->add_control(
			'slider_dots_active',
			[
				'label' => esc_html__( 'Active Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .slider .owl-dots div.active' => 'background-color: {{VALUE}}',
				],
				'default' => '#635cdb'
			]
		);

		//Slider DOT Border radius
		$this->add_control(
			'dot-border-radius',
			[
				'label' => esc_html__( 'Border Radius', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .slider .owl-dots div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$sliders = $settings['sliders'];
		$slider_items = $settings['slider_items'];
		$slider_autoplay = $settings['slider_autoplay'];
		$slider_dots = $settings['slider_dots'];
		$slider_timeout = $settings['slider_timeout'];
		

		
		if($slider_autoplay == 'true') {
			$slider_autoplay = 'false';
		}else {
			$slider_autoplay = 'true';
		}

		//Slider dots
		if($slider_dots == 'true') {
			$slider_dots = 'false';
		}else {
			$slider_dots = 'true';
		}
		
	?>

			<script>
				jQuery(document).ready(function($) {
					/* Slider Item Slide
					============================*/
					$(".slider").owlCarousel({
							items: <?php echo $slider_items; ?>,
							autoplay: <?php echo $slider_autoplay; ?>,
							loop: true,
							nav: false,
							dots: <?php echo $slider_dots; ?>,
							smartSpeed: 500,
                            autoplayTimeout: <?php echo $slider_timeout; ?>,
							responsiveClass: true,
							responsive: {
								0:{
									items:1,
									dots: false
								},

								850:{
									items:1,
									dots: true
								},
								

								1000:{
									items: <?php echo $slider_items; ?>,
									dots: <?php echo $slider_dots; ?>
								}
							}
						});

				});
			</script>


		<!-- Slider Area Start -->
			
        <div class="slider owl-carousel">
			<?php
				foreach($sliders as $slider) {
					?>

							<div class="single-slide" style="background-image:url(' <?php echo $slider['slider_image']['url']; ?> ')">
								<div class="container">
									<div class="row">
										<div class="col-xl-12">
											<div class="slide-table">
											<div class="slide-tablecell">
												<h4> <?php echo $slider['slider_subtitle']; ?> </h4>
												<h2> <?php echo $slider['slider_title']; ?> </h2>
												<p> <?php echo $slider['slider_desc']; ?> </p>
												<a href="<?php echo $slider['slider_btn_url']; ?>" class="box-btn"> <?php echo $slider['slider_btn_text']; ?> <i class="fa fa-angle-double-right"></i></a>
											</div>
											</div>
										</div>
									</div>
								</div>
							</div>

					<?php
				} 
			?>

        </div>
      
      <!-- Slider Area Start -->


	<?php
		
    }
}