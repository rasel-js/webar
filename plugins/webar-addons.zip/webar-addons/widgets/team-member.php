<?php

class Elementor_Team_Member_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'team_member_widget';
	}

	public function get_title() {
		return esc_html__( 'Team Member', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'team', 'member' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ** All controls start
	
			// Team Image
			$this->add_control(
				'team_image',
				[
					'label' => esc_html__( 'Choose Image', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);
	
			// Team Name
			$this->add_control(
				'team_name',
				[
					'label' => esc_html__( 'Name', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'john doe', 'webar-addons' ),
					'placeholder' => esc_html__( 'Type your team name', 'webar-addons' ),
					'label_block' => true,
				]
			);

			// Team Designation
			$this->add_control(
				'team_designation',
				[
					'label' => esc_html__( 'Designation', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'web developer', 'webar-addons' ),
					'placeholder' => esc_html__( 'Type your team designation', 'webar-addons' ),
					'label_block' => true,
				]
			);

		// Team Socials Show/Hide
		$this->add_control(
			'show_team_socials',
			[
				'label' => esc_html__( 'Social Link', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Hide', 'webar-addons' ),
				'label_off' => esc_html__( 'Show', 'webar-addons' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'separator' => 'before'
			]
		);

		$repeater = new \Elementor\Repeater();


		$repeater->add_control(
			'team_icon_name',
			[
				'label' => esc_html__( 'Name', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Icon Name', 'webar-addons' ),
				'placeholder' => esc_html__( 'Type your team name', 'webar-addons' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'team_icon', [
				'label' => esc_html__( 'Icon', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$repeater->add_control(
			'team_link', [
				'label' => esc_html__( 'URL', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'webar-addons' ),
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					'custom_attributes' => '',
				],
			]
		);

		$this->add_control(
			'team_socials',
			[
				'label' => esc_html__( 'Social List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'webar-addons' ),
					],
					[
						'list_title' => esc_html__( 'Title #2', 'webar-addons' ),
					],
					[
						'list_title' => esc_html__( 'Title #3', 'webar-addons' ),
					],
				],
				'title_field' => '{{{ team_icon_name }}}',
				'condition' => [
					'show_team_socials' => 'yes'
				]
			]
		);
		$repeater->add_control(
			'team_animation',
			[
				'label' => esc_html__( 'Entrance Animation', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::ANIMATION,
				'prefix_class' => 'animated ',
			]
		);

		
        $this->end_controls_section();


		//********  Style control start **************************************************
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			//Overlay Color
			$this->add_control(
				'team_overlay_color',
				[
					'label' => esc_html__( 'Overlay Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .team-hover:before' => 'background-color: {{VALUE}}',
					],
					'default' => '#333'
				]
			);

			//Name color
			$this->add_control(
				'team_name_color',
				[
					'label' => esc_html__( 'Name Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .team-hover h4' => 'color: {{VALUE}}',
					],
					'default' => '#fff',
					'separator' => 'before'
				]
			);


		//Team name Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'team_name_typography',
				'selector' => '{{WRAPPER}} .team-hover h4',
			]
		);


			//Team Designation color
			$this->add_control(
				'team_designation_color',
				[
					'label' => esc_html__( 'Designation Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .team-hover h4 span' => 'color: {{VALUE}}',
					],
					'default' => '#fff',
					'separator' => 'before'
				]
			);


		//Team name Typography
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'team_designation_typography',
				'selector' => '{{WRAPPER}} .team-hover h4 span',
			]
		);


			//Social icon color
			$this->add_control(
				'team_social_icon_color',
				[
					'label' => esc_html__( 'Social Icon Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .team-hover ul li a' => 'color: {{VALUE}}',
					],
					'default' => '#fff',
					'separator' => 'before',
					'condition' => [
						'show_team_socials' => 'yes'
					]
				]
			);

			//Social icon color
			$this->add_control(
				'team_social_icon_bg_color',
				[
					'label' => esc_html__( 'Icon Background Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .team-hover ul li' => 'background-color: {{VALUE}}',
					],
					'default' => '#333',
					'condition' => [
						'show_team_socials' => 'yes'
					]
				]
			);
		


		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		
		$team_image = $settings['team_image'];
		$team_name = $settings['team_name'];
		$team_designation = $settings['team_designation'];
		$team_socials = $settings['team_socials'];
		
		

	?>
				<div class="single-team">
                    <img src="<?php echo $team_image['url'];?>" alt="<?php echo $team_name;?>">
                     <div class="team-hover">
                        <div class="team-content">
                           <h4><?php echo $team_name;?> <span><?php echo $team_designation;?></span></h4>

						   <?php 
						 		if($team_socials) {
									 ?>
										<ul>
											<?php 
												foreach($team_socials as $social) {
													?>
														<li><a href="<?php echo $social['team_link']['url'];?>"><i class="<?php echo $social['team_icon']['value'];?>"></i></a></li>
													<?php
												}
											?>
											
										</ul>
									 
									 <?php
								 }  
						   ?>
                         
                        </div>
                    </div>
                </div>


	<?php
		
    }
}