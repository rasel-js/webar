<?php

class Elementor_Testimonial_Widget extends \Elementor\Widget_Base {

    public function get_name() {
		return 'testimonial_widget';
	}

	public function get_title() {
		return esc_html__( 'Testimonial', 'webar-addons' );
	}

	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}

	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}

	public function get_categories() {
		return [ 'webar_category' ];
	}

	public function get_keywords() {
		return [ 'testimonial', 'carousel' ];
	}

    protected function register_controls(){

        $this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		// ****** All controls start ****************
	
		//slider repeater
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'client_image',
			[
				'label' => esc_html__( 'Client Image', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'client_description', [
				'label' => esc_html__( 'Description', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( '" Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad assumenda culpa cumque dicta sint soluta voluptas eius iusto modi reprehenderit sint soluta voluptas. "' , 'webar-addons' ),
				
			]
		);

		$repeater->add_control(
			'client_name', [
				'label' => esc_html__( 'Name', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Sayed Balkhy' , 'webar-addons' ),
				'separator' => 'before'
			]
		);

		$repeater->add_control(
			'client_designation', [
				'label' => esc_html__( 'Designation', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'UIUX Expert' , 'webar-addons' ),

			]
		);

		
		$this->add_control(
			'client_list',
			[
				'label' => esc_html__( 'Client List', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'webar-addons' ),
					],
					[
						'list_title' => esc_html__( 'Title #2', 'webar-addons' ),
					],
					[
						'list_title' => esc_html__( 'Title #3', 'webar-addons' ),
					],
				],
				'title_field' => '{{{ client_name }}}',
			]
		);

        $this->end_controls_section();


		//Content Setting section ******************************
		$this->start_controls_section(
			'content_setting',
			[
				'label' => esc_html__( 'Settings', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'testi_count',
			[
				'label' => esc_html__( 'Items', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 5,
				'step' => 1,
				'default' => 3,
			]
		);

		$this->add_control(
			'testi_timeout',
			[
				'label' => esc_html__( 'Time Out', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1000,
				'max' => 80000,
				'step' => 1,
				'default' => 3000,
			]
		);

		$this->add_control(
			'autoplay', [
			
				'label' => esc_html__( 'Autoplay?', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'webar-addons' ),
				'label_off' => esc_html__( 'Off', 'webar-addons' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);



		$this->end_controls_section();

		//Style control
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'webar-addons' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			// Ui control heading
			$this->add_control(
				'border_color',
				[
					'label' => esc_html__( 'Border color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

			//Boder color control
			$this->add_control(
				'border_color_control',
				[
					'label' => esc_html__( 'Border Color', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .section-title::after, .section-title::before' => 'background-color: {{VALUE}}',
					],
					'default' => '#B0ADEC'
				]
			);

		// Ui control heading
		$this->add_control(
			'sub_title_heading',
			[
				'label' => esc_html__( 'Section Subtitle', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		//Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'selector' => '{{WRAPPER}} .section-title h3 span',
			]
		);

		//Subtitle color control
		$this->add_control(
			'subtitle_color',
			[
				'label' => esc_html__( 'Sub-title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title h3 span' => 'color: {{VALUE}}',
				],
				'default' => '#333333'
			]
		);

			// Ui control heading
			$this->add_control(
				'main_title_heading',
				[
					'label' => esc_html__( 'Section Title', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

		//Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .section-title h3',
			]
		);

		//Title color control
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title h3' => 'color: {{VALUE}}',
				],
				'default' => '#333333'
			]
		);

			// Ui control heading
			$this->add_control(
				'desc_title',
				[
					'label' => esc_html__( 'Section Description', 'webar-addons' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);

		//Typography control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',
				'selector' => '{{WRAPPER}} .section-title p',
			]
		);

		//Description color control
		$this->add_control(
			'desc_color',
			[
				'label' => esc_html__( 'Description Color', 'webar-addons' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title p' => 'color: {{VALUE}}',
				],
				'default' => '#333333'
			]
		);


		$this->end_controls_section();
    }

	//Content rendering
    protected function render() {
        $settings = $this->get_settings_for_display();

		$client_list = $settings['client_list'];
		$testi_count = $settings['testi_count'];
		$autoplay = $settings['autoplay'];
		$testi_timeout = $settings['testi_timeout'];
		
		if($autoplay == 'true') {
			$autoplay = 'false';
		}else {
			$autoplay = 'true';
		}
	?>

		<script>
			jQuery(document).ready(function($) {
				/* Testimonials Itesm Slide
				============================*/
				$(".testimonials").owlCarousel({
					items: <?php echo $testi_count; ?>,
					autoplay: <?php echo $autoplay; ?>,
					loop: true,
					autoplayTimeout: <?php echo $testi_timeout; ?>,
					margin: 30,
					nav: false,
					dots: true,
					center: true,
					responsive: {
						0: {
							items: 1,
						},
						600: {
							items: <?php echo $testi_count; ?>,
						},
						1000: {
							items: <?php echo $testi_count; ?>,
						}
					}
				});
			});
			
		</script>

				<div class="testimonials owl-carousel">
					<?php
						foreach($client_list as $clients) {
							?>
    							<div class="single-testimonial">
                        			<div class="testi-img">
                           			<img src="<?php echo $clients['client_image']['url'];?>" alt="" />
                        			</div>
                        				<p>" <?php echo $clients['client_description'];?> "</p>
                        			<h4><?php echo $clients['client_name'];?> <span><?php echo $clients['client_designation'];?></span></h4>
                    			</div>								
							<?php
						} 
					?>
                
                    
                </div>


	<?php
		
    }
}